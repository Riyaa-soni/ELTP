export const pokemons = [
    { id: 1, name: "Charizard" },
    { id: 2, name: "Pikachu" },
    { id: 3, name: "Bulbasaur" },
    { id: 4, name: "Togepi" },
]