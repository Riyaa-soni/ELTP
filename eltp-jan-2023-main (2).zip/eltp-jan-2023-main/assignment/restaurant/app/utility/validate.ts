import { NextFunction, Request, Response } from "express";
import { validationResult } from 'express-validator';

export const validate = (req: Request, res: Response, next: NextFunction) => {
    try {
        const errors = validationResult(req);
        if(!errors.isEmpty()) throw { statusCode: 403, errors: errors.array() };

        next();
    } catch (e) {
        next(e);
    }
}