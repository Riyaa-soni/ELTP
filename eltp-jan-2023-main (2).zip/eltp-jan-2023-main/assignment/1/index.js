// get references of elements
var images = [
    "1.png",
    "2.png",
    "3.png"
];
var index = 0;
var deleteBtn = document.getElementById('delete');
var prevBtn = document.getElementById('prev');
var nextBtn = document.getElementById('next');
var addBtn = document.getElementById('add');
var image = document.getElementById('img');
var imageURL = document.getElementById('image-url');
image === null || image === void 0 ? void 0 : image.setAttribute("src", images[index]);
deleteBtn === null || deleteBtn === void 0 ? void 0 : deleteBtn.addEventListener('click', function () {
    images.splice(index, 1);
    if (images.length) {
        image === null || image === void 0 ? void 0 : image.setAttribute("src", images[index]);
    }
});
nextBtn === null || nextBtn === void 0 ? void 0 : nextBtn.addEventListener('click', function () {
    index++;
    index = index % images.length;
    image === null || image === void 0 ? void 0 : image.setAttribute("src", images[index]);
});
prevBtn === null || prevBtn === void 0 ? void 0 : prevBtn.addEventListener('click', function () {
    index--;
    index = index < 0 ? images.length - 1 : index;
    image === null || image === void 0 ? void 0 : image.setAttribute("src", images[index]);
});
addBtn === null || addBtn === void 0 ? void 0 : addBtn.addEventListener('click', function () {
    if (imageURL.value) {
        images.push(imageURL.value);
    }
});
