// get references of elements

const images = [
    "1.png",
    "2.png",
    "3.png"
];

let index = 0;

const deleteBtn = document.getElementById('delete');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const addBtn = document.getElementById('add');
const image = document.getElementById('img');
const imageURL = document.getElementById('image-url') as HTMLInputElement;

image?.setAttribute("src", images[index]);

deleteBtn?.addEventListener('click', () => {
    images.splice(index, 1);
    if(images.length) {
        image?.setAttribute("src", images[index]);
    }
});

nextBtn?.addEventListener('click', () => {
    index++;
    index = index % images.length;
    image?.setAttribute("src", images[index]);
})

prevBtn?.addEventListener('click', () => {
    index--;
    index = index < 0 ? images.length - 1 : index;
    image?.setAttribute("src", images[index]);
})

addBtn?.addEventListener('click', () => {
    if(imageURL.value) {
        images.push(imageURL.value);
    }
});