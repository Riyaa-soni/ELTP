const add = (n1, n2) => n1 + n2;

// named export
export const subtract = (n1, n2) => n1 - n2;

// default export
// can be done only once
export default {
    add, 
    subtract
}

// cannot do this
// export add;



// module.exports = {
//     add,
//     subtract
// }