// const dotenv = require('dotenv');
// dotenv.config();

// CommonJS modules
// const { add, subtract } = require('./math')
import ganit, { subtract as sb } from './math.js';
console.log("hi this is index.js");

console.log(math.add(5, 3));