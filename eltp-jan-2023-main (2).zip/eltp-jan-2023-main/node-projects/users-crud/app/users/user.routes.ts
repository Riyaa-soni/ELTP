import { Router } from 'express';
import { ResponseHandler } from '../utility/response-handler';
import userService from './user.service';

const router = Router();

router.get("/", (req, res, next) => {
    try {
        const result = userService.findAll();
        res.send(new ResponseHandler(result));
    } catch (e: any) {
        next(e);
    }
});

// create a user
router.post("/", (req, res, next) => {
    try {
        const result = userService.create(req.body);
        res.send(new ResponseHandler(result));
    } catch (e: any) {
        next(e);
    }
});

// replace the record
router.put("/", (req, res, next) => {
    try {
        const result = userService.update(req.body);
        res.send(new ResponseHandler(result));
    } catch (e: any) {
        next(e);
    }
});

// update the record
router.patch("/", (req, res, next) => {
    try {
        const result = userService.update(req.body);
        res.send(new ResponseHandler(result));
    } catch (e: any) {
        next(e);
    }
});

// delete the record
router.delete("/:id", (req, res, next) => {
    try {
        const result = userService.remove(req.params.id);
        res.send(new ResponseHandler(result));
    } catch (e: any) {
        next(e);
    }
});

export default router;