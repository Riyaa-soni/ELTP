import { v4 } from "uuid";
import { IUser, Users } from "./user.types";

export class UserSchema {
    private static users: Users = [];

    static findAll(): Users {
        return UserSchema.users;
    }

    static create(user: IUser): IUser {
        const id = v4();
        const userRecord = { ...user, id }
        UserSchema.users.push(userRecord);

        return userRecord;
    }

    static update(user: IUser): boolean {
        const index = UserSchema.users.findIndex(u => u.id === user.id);
        if(index === -1) return false;

        UserSchema.users[index] = { ...user, id: UserSchema.users[index].id };
        return true;
    }

    static remove(id: string): boolean {
        const index = UserSchema.users.findIndex(u => u.id === id);
        if(index === -1) return false;

        UserSchema.users.splice(index, 1);
        return true;
    }
}