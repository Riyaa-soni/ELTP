export interface IUser {
    id: string;
    name: string;
}

export type Users = IUser[];