import { UserSchema } from "./user.schema";
import { IUser } from "./user.types";

const create = (user: IUser) => UserSchema.create(user);

const findAll = () => UserSchema.findAll();

const update = (user: IUser) => UserSchema.update(user);


const remove = (id: string) => UserSchema.remove(id);


export default {
    create,
    findAll,
    update,
    remove
}