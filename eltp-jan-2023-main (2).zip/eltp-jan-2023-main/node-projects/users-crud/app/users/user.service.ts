import userRepo from "./user.repo";
import { UserResponse } from "./user.responses";
import { IUser } from "./user.types";

const create = (user: IUser) => {
    userRepo.create(user);
    return UserResponse.USER_CREATED;
}

const findAll = () => userRepo.findAll();

const update = (user: IUser) => {
    const didUpdate = userRepo.update(user);
    if(didUpdate) return UserResponse.USER_UPDATED;

    throw UserResponse.USER_NOT_FOUND;
}

const remove = (id: string) => {
    const didDelete = userRepo.remove(id);
    if(didDelete) return UserResponse.USER_DELETED;

    throw UserResponse.USER_NOT_FOUND;
}

export default {
    create,
    findAll,
    update,
    remove
}