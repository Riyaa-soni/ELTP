export const UserResponse = {
    USER_NOT_FOUND: {
        statusCode: 404,
        message: "User not found"
    },
    USER_UPDATED: {
        statusCode: 200,
        message: "User Updated Successfully"
    },
    USER_DELETED: {
        statusCode: 200,
        message: "User Deleted Successfully"
    },
    USER_CREATED: {
        statusCode: 201,
        message: "User Created Successfully"
    }
}