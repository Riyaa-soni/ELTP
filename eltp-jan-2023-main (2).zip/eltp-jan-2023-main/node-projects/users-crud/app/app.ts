import express from 'express';
import { registerRoutes } from './routes/routes';

export const startServer = () => {
    const app = express();

    registerRoutes(app);

    const { PORT } = process.env;
    app.listen(
        PORT || 7654,
        () => console.log(`SERVER STARTED ON PORT ${PORT || 7654}`)
    )
}