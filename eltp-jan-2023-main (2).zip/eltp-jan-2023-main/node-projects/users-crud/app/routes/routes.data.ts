import { Route, Routes } from './routes.types';
import UserRouter from '../users/user.routes';

export const routes: Routes = [
    new Route("/users", UserRouter)
];