import { Document, model } from "mongoose";
import { BaseSchema } from "../../utility/base-schema";
import { IRole } from "./role.types";

const RoleSchema = new BaseSchema({
    name: {
        type: String,
        required: true
    }
});

type RoleDocument = Document & IRole

export const RoleModel = model<RoleDocument>("Role", RoleSchema);