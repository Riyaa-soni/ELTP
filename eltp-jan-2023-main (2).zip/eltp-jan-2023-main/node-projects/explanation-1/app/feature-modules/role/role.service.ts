import roleRepo from "./role.repo";

const getById = (id: string) => roleRepo.getById(id);

export default {
    getById
}