import { Schema } from "mongoose";

export interface IRole {
    _id: string | Schema.Types.ObjectId,
    name: string
}