import { RoleModel } from "./role.schema";

const getById = (id: string) => RoleModel.find({ _id: id });

export default {
    getById
}