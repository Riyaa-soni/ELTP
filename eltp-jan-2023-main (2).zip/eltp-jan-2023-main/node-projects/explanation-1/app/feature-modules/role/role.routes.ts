import { Router } from "express";
import { ResponseHandler } from "../../utility/response-handler";
import roleService from "./role.service";

const router = Router();

router.get("/:id", async (req, res, next) => {
    try {
        const { id } = req.params;
        const result = await roleService.getById(id);
        res.send(new ResponseHandler(result));
    } catch(e) {
        next(e);
    }
})

export default router;