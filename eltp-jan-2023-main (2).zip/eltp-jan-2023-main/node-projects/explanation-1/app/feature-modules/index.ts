import UserRouter from './users/users.routes';
import RoleRouter from './role/role.routes';
export default {
    UserRouter,
    RoleRouter
}