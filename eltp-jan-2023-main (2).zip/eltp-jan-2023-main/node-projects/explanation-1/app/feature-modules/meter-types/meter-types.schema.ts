import { model } from "mongoose";
import { BaseSchema } from "../../utility/base-schema";

const meterTypeSchema = new BaseSchema({
    name: {
        type: String,
        required: true
    }
});

type MeterTypeDocument = Document & { _id?: any, name: string };

export const MeterTypeModel = model<MeterTypeDocument>("MeterType", meterTypeSchema);