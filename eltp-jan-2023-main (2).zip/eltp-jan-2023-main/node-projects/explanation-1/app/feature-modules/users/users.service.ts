import { Schema } from "mongoose";
import usersRepo from "./users.repo";
import { USER_RESPONSE } from "./users.responses";
import { IUser } from "./users.types";

const create = (user: IUser) => usersRepo.create(user);

const find = () => usersRepo.find();

const findOne = async (filter: Partial<IUser>) => {
    const user = await usersRepo.findOne(filter);
    if(!user) throw USER_RESPONSE.NOT_FOUND

    return user;
}

const update = (user: IUser) => usersRepo.update(user);

const deleteOne = (id: string) => usersRepo.deleteOne(id);

export default {
    create,
    find, 
    findOne,
    update,
    deleteOne
}