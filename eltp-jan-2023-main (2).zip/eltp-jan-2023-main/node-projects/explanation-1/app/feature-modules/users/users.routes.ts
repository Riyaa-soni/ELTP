import { NextFunction, Request, Response, Router } from "express";
import { permit } from "../../utility/authorize";
import { ResponseHandler } from "../../utility/response-handler";
import usersService from "./users.service";
import { CREATE_USER_VALIDATION, UPDATE_USER_VALIDATION } from "./users.validations";

const router = Router();

// find all
router.get("/", async (req, res, next) => {
    try {
        const result = await usersService.find();
        res.send(new ResponseHandler(result));
    } catch (e) {
        console.log(e);
        next(e);
    }
});

router.get("/:id", async (req, res, next) => {
    try {
        const { id } = req.params;
        const result = await usersService.findOne({ _id: id });
        res.send(new ResponseHandler(result));
    } catch (e) {
        next(e);
    }
});

router.post("/",
    CREATE_USER_VALIDATION,
    async (
        req: Request,
        res: Response,
        next: NextFunction
    ) => {
        try {
            const user = req.body;
            const result = await usersService.create(user);
            res.send(new ResponseHandler(result));
        } catch (e) {
            next(e);
        }
    });

router.put("/",
    UPDATE_USER_VALIDATION,
    async (
        req: Request,
        res: Response,
        next: NextFunction
    ) => {
        try {
            const user = req.body;
            const result = await usersService.update(user);
            res.send(new ResponseHandler(result));
        } catch (e) {
            next(e);
        }
    });

router.delete("/:id", async (req, res, next) => {
    try {
        const { id } = req.params;
        const result = await usersService.deleteOne(id);
        res.send(new ResponseHandler(result));
    } catch(e) {
        next(e);
    }
})


export default router;