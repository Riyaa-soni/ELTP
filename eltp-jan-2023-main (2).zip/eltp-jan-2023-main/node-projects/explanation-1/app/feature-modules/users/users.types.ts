import { Schema } from "mongoose";

export interface IUser {
    _id?: string,
    name: string,
    email: string,
    password: string,
    roles: (Schema.Types.ObjectId | string)[]
}