import { Schema, Types } from "mongoose";
import { UserModel } from "./users.schema";
import { IUser } from "./users.types";

const create = (user: IUser) => UserModel.create(user); 

const find = async () => {
    try {
        const users = await UserModel.find({ isDeleted: false }).populate("roles").populate("meterType");
        return users;
    } catch(e) {
        throw e;
    }
} 

const findOne = (filters: Partial<IUser>) => UserModel.findOne({ 
    ...filters,
    isDeleted: false
});

const update = (user: IUser) => UserModel.updateOne(
    { _id: new Types.ObjectId(user._id) }, 
    user
);

const deleteOne = (id: string) => UserModel.updateOne(
    { _id: new Types.ObjectId(id) }, 
    { isDeleted: true }
);

export default {
    create,
    find, 
    findOne,
    update,
    deleteOne
}