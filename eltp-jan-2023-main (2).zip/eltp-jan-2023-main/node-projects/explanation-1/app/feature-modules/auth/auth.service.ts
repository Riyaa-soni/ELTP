

const register = (user: any) => {

}

const createAdmin = (admin: any) => {
    admin.role = "abvcjf;lkdsfj";
    register(admin);
}

const createEmployee = (employee: any) => {
    employee.role = "aud";
    register(employee);
}

export default {
    createAdmin,
    createEmployee
}