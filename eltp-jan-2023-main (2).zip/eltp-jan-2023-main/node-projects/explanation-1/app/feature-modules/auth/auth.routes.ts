import { Router } from "express";
import authService from "./auth.service";


const router = Router();

// create admin
router.post("/admin", (req, res, next) => {
    authService.createAdmin(req.body);
})

router.post("/employee", (req, res, next) => {
    authService.createEmployee(req.body);
})