import { NextFunction, Request, Response } from "express";
import { verify } from "jsonwebtoken";


export const authorize = (excludedPaths: ExcludedPaths) => {
    return (req: Request, res: Response, next: NextFunction) => {
        try {
            if (excludedPaths.find(e => e.path === req.url && e.method === req.method)) {
                return next();
            }

            const token = req.headers.authorization;
            if (!token) return next({ message: 'UNAUTHORIZED', statusCode: 401 });

            const { JWT_SECRET } = process.env;
            const user = verify(token, JWT_SECRET || '');

            res.locals.user = user;

            next();
        } catch (e) {
            next({ message: 'UNAUTHORIZED', statusCode: 401 });
        }

    }
}


export const permit = (roles: string[]) => {
    return (req: Request, res: Response, next: NextFunction) => {
        const { user } = res.locals;
        if (roles.includes(user.role)) return next();

        next({ statusCode: 403, message: "FORBIDDEN" })
    }
}

type Method = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

type Strings = string[];

export class ExcludedPath {
    paramsToExclude: Strings[]
    constructor(
        public path: string,
        public method: Method,
        ...paramsToExclude: Strings[]
    ) {
        this.paramsToExclude = paramsToExclude;
    }
}

export type ExcludedPaths = ExcludedPath[];