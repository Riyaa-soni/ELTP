import { Route, Routes } from "./routes.types";
import Routers from '../feature-modules/index';
import { ExcludedPath, ExcludedPaths } from "../utility/authorize";

// use this as a dummy, just to register the schema
new Route("/roles", Routers.RoleRouter);
export const routes: Routes = [
    new Route("/users", Routers.UserRouter),
];


// users/admin, GET
export const excludedPaths: ExcludedPaths = [
    new ExcludedPath("/auth/login", "POST")
];