import { config } from "dotenv";
import { Types } from "mongoose";
config();

import { startServer } from "./app/app";
import authService from "./app/feature-modules/auth/auth.service";
startServer();

authService.create({
    name: "admin",
    email: "admin@restaurant.com",
    password: "1234",
    roles: [new Types.ObjectId("64215cc9542b1750fe23eaf2")]
})