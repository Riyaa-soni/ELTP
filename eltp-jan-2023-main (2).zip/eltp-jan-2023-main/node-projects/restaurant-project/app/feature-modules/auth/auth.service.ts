import { sign } from "jsonwebtoken";
import usersService from "../users/users.service";
import { IUser } from "../users/users.types";
import { AUTH_RESPONSES } from "./auth.responses";
import { ICredentials } from "./auth.types";


const login = async (credentials: ICredentials) => {
    const user = await usersService.findOne(credentials);
    if(!user) AUTH_RESPONSES.INVALID_CREDENTIALS;

    const { _id } = user;
    const { JWT_SECRET } = process.env;
    
    const token = sign({ id: _id }, JWT_SECRET || '');
    return { token, roles: user.roles };
}

const create = (user: IUser) => {
    usersService.create(user);
}

export default {
    login
}