import { config } from "dotenv";
config();

import { startServer } from "./app/app";
startServer();

// populating default values.
import roleService from "./app/role/role.service";
import authService from "./app/auth/auth.service";
import { ROLES } from "./app/utility/constants";

const populateDb = () => {
    console.log("populating")
    roleService.create({ name: 'admin', id: ROLES.ADMIN });
    roleService.create({ name: 'trainer', id: ROLES.TRAINER });

    authService.register({ id: '1', email: 'admin@poke.com', password: 'pokemon', role: ROLES.ADMIN });
}

console.log("before populating")
populateDb();