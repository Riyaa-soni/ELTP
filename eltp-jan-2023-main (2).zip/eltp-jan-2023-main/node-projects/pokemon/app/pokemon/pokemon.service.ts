import pokemonRepo from "./pokemon.repo";
import { IPokemon } from "./pokemon.types";


const create = (pokemon: IPokemon) => pokemonRepo.create(pokemon);
const findAll = () => pokemonRepo.findAll();

export default {
    create,
    findAll
}