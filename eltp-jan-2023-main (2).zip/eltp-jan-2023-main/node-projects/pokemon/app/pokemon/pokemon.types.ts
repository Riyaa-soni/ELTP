export interface IPokemon {
    id: string;
    name: string;
    imageURL: string;
}

export type Pokemons = IPokemon[];