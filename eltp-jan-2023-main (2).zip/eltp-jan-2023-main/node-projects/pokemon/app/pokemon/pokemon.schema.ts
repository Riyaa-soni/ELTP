import { v4 } from "uuid";
import { IPokemon, Pokemons } from "./pokemon.types";


export class PokemonSchema {
    private static pokemons: Pokemons = [];

    static create(pokemon: IPokemon) {
        const pokemonRecord = { ...pokemon, id: v4() };
        PokemonSchema.pokemons.push(pokemonRecord);
        return pokemonRecord;
    }

    static findAll() {
        return PokemonSchema.pokemons;
    }
}