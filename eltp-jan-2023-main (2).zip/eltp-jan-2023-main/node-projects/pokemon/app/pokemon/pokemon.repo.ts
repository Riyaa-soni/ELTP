import { PokemonSchema } from "./pokemon.schema";
import { IPokemon } from "./pokemon.types";


const create = (pokemon: IPokemon) => PokemonSchema.create(pokemon);
const findAll = () => PokemonSchema.findAll();

export default {
    create,
    findAll
}