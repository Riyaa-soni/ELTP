import { checkSchema } from "express-validator";
import { validate } from "../utility/validate";

export const CREATE_POKEMON_VALIDATOR = [
    ...checkSchema({
        name: { in: 'body', isString: true, errorMessage: 'name is required' },
        imageURL: { in: 'body', isString: true , errorMessage: 'imageURL is required' }
    }),
    validate
]