import { NextFunction, Request, Response, Router } from "express";
import { ResponseHandler } from "../utility/response-handler";
import pokemonService from "./pokemon.service";
import { CREATE_POKEMON_VALIDATOR } from "./pokemon.validator";

const router = Router();

router.get("/", (req, res, next) => {
    try {
        const result = pokemonService.findAll();
        res.send(new ResponseHandler(result));
    } catch(e) {
        next(e);
    }
});

router.post("/", CREATE_POKEMON_VALIDATOR, (req:Request, res: Response, next: NextFunction) => {
    try {
        const pokemon = req.body;
        const result = pokemonService.create(pokemon);
        res.send(new ResponseHandler(result));
    } catch(e) {
        next(e);
    }
})

export default router;