import { v4 } from "uuid";
import { IRole, RolePredicate, Roles } from "./role.types";


export class RoleSchema {
    private static roles: Roles = [];

    static create(role: IRole) {
        const roleRecord = { ...role };
        RoleSchema.roles.push(roleRecord);
        return roleRecord;
    }

    static findOne(cb: RolePredicate) {
        return RoleSchema.roles.find(cb);
    }
}