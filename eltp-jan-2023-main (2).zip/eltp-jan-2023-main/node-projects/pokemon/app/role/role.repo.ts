import { RoleSchema } from "./role.schema";
import { IRole, RolePredicate } from "./role.types";


const create = (role: IRole) => RoleSchema.create(role);
const findOne = (cb: RolePredicate) => RoleSchema.findOne(cb);

export default {
    create,
    findOne
}