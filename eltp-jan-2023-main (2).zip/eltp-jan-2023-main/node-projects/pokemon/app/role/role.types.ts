export interface IRole {
    id: string;
    name: string;
}

export type Roles = IRole[];

export type RolePredicate = (r: IRole) => boolean;