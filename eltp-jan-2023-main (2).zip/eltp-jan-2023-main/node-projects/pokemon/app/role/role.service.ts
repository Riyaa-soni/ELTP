import roleRepo from "./role.repo";
import { IRole, RolePredicate } from "./role.types";

const create = (role: IRole) => roleRepo.create(role);
const findOne = (cb: RolePredicate) => roleRepo.findOne(cb);

export default {
    create,
    findOne
}