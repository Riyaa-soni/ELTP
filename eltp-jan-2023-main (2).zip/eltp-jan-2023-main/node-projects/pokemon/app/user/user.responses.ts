export const USER_RESPONSES = {
    UPDATE_FAILED: {
        statusCode: 400,
        message: "Your update request failed"
    },
    UPDATE_SUCCESSFUL: {
        statusCode: 200,
        message: "User Updated"
    }
}