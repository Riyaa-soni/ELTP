import { Router } from "express";
import { checkSchema } from "express-validator";
import { ResponseHandler } from "../utility/response-handler";
import userService from "./user.service";

const router = Router();

// update pokemon list
router.put("/pokemon", (req, res, next) => {
    try {
        const user = req.body;
        const result = userService.updatePokemons(user);
        res.send(new ResponseHandler(result));
    } catch (e) {
        next(e);
    }
})

export default router;