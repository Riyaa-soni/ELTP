import { UserSchema } from "./user.schema";
import { IUser, UserPredicate } from "./user.types";


const create = (user: IUser) => UserSchema.create(user);

const findOne = (cb: UserPredicate) => UserSchema.findOne(cb); 

const update = (user: IUser) => UserSchema.update(user);

export default {
    create,
    findOne,
    update
}