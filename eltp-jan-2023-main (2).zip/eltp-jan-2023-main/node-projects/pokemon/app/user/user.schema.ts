import { IUser, UserPredicate, Users } from "./user.types";
import { v4 } from "uuid";

export class UserSchema {
    private static users: Users = [];

    static create(user: IUser) {
        try {
            const id = v4();
            const userRecord = { ...user, id }
            UserSchema.users.push(userRecord);
            return userRecord;
        } catch (e) {
            throw { message: "record not created", stack: e }
        }
    }

    static findOne(cb: UserPredicate) {
        return UserSchema.users.find(cb);
    }

    static update(user: IUser) {
        const userIndex = UserSchema.users.findIndex(u => u.id === user.id);
        if(userIndex === -1) return false;

        UserSchema.users[userIndex] = { ...UserSchema.users[userIndex], ...user };
        return true;
    }
}

// UserSchema.findOne(u => u.email === 'abc@gmail.com' && u.password === 'pwd');
// UserSchema.findOne(u => u.id === '1234567890');
// UserSchema.findOne(u => u.email !== 'abcd@gmail.com');
// UserSchema.findOne(u => u.email === 'abc' || u.id === '1');