import userRepo from "./user.repo";
import { USER_RESPONSES } from "./user.responses";
import { IUser, UserPredicate } from "./user.types";

const create = (user: IUser) => userRepo.create(user);

const findOne = (cb: UserPredicate) => userRepo.findOne(cb);

const updatePokemons = (user: IUser) => {
    const didUpdate = userRepo.update(user);
    if(!didUpdate) throw USER_RESPONSES.UPDATE_FAILED;

    return USER_RESPONSES.UPDATE_SUCCESSFUL;
}

export default {
    create,
    findOne,
    updatePokemons
}