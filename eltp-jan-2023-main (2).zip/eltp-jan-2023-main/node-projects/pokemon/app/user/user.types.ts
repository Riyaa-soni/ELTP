import { Pokemons } from "../pokemon/pokemon.types";

export interface IUser {
    id: string;
    email: string;
    password: string;
    role: string;
    pokemons?: Pokemons;
}

export type Users = IUser[];

export type UserPredicate = (u: IUser) => boolean;

let user: IUser;
export type UserKeys = keyof typeof user;

