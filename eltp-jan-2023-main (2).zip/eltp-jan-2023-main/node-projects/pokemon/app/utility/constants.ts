export const ROLES = {
    ADMIN: '1',
    TRAINER: '2'
}