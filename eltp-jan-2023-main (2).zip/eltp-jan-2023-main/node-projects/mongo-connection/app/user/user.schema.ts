import { IUser, UserPredicate, Users } from "./user.types";
import { v4 } from "uuid";
import { Schema, model, Document } from "mongoose";
import { BaseSchema } from "../utility/base-schema";

const userSchema = new BaseSchema({
    email: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
});

type UserDocument = Document & IUser;

export const UserModel = model<UserDocument>("User", userSchema);


// export class UserSchema {
//     private static users: Users = [];

//     static create(user: IUser) {
//         try {
//             const id = v4();
//             const userRecord = { ...user, id }
//             UserSchema.users.push(userRecord);
//             return userRecord;
//         } catch (e) {
//             throw { message: "record not created", stack: e }
//         }
//     }

//     static findOne(cb: UserPredicate) {
//         return UserSchema.users.find(cb);
//     }
// }

// UserSchema.findOne(u => u.email === 'abc@gmail.com' && u.password === 'pwd');
// UserSchema.findOne(u => u.id === '1234567890');
// UserSchema.findOne(u => u.email !== 'abcd@gmail.com');
// UserSchema.findOne(u => u.email === 'abc' || u.id === '1');