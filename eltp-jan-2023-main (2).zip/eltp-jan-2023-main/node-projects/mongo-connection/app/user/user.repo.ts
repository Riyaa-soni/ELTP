import { UserModel } from "./user.schema";
import { IUser, UserPredicate } from "./user.types";


const create = (user: IUser) => UserModel.create(user);

// change here
const findOne = (cb: any) => UserModel.findOne(cb); 

export default {
    create,
    findOne
}