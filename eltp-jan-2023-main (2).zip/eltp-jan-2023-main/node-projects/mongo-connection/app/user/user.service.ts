import userRepo from "./user.repo";
import { IUser, UserPredicate } from "./user.types";

const create = (user: IUser) => userRepo.create(user);

// change here
const findOne = (cb: any) => userRepo.findOne(cb);

export default {
    create,
    findOne
}