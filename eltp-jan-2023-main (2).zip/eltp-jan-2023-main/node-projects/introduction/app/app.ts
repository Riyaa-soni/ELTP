// express import is a function
import express from 'express';


export const createServer = () => {
    // creates a new express instance and returns it
    const app = express();
    // this app is the central express app constant
    // all configurations and additions will happen
    // on this instance.

    const { PORT } = process.env; 
    app.listen(
        PORT || 3000,
        () => console.log(`SERVER STARTED ON PORT: ${PORT || 3000}`)
    )
}