import { Route, Routes } from "./routes.types";
import Routers from '../feature-modules/index';
import { ExcludedPath, ExcludedPaths } from "../utility/authorize";

export const routes: Routes = [
    new Route("/users", Routers.UserRouter),
    new Route("/auth", Routers.AuthRouter)
];


// users/admin, GET
export const excludedPaths: ExcludedPaths = [
    new ExcludedPath("/auth/login", "POST"),
    new ExcludedPath("/users/:id/:category", "GET", ["admin", "managers"], ["cat1", "cat2"])
];