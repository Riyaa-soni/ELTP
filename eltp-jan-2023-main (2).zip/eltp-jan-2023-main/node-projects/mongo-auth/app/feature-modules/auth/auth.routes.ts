import { Router } from "express";
import { authorize } from "../../utility/authorize";
import { ResponseHandler } from "../../utility/response-handler";
import authService from "./auth.service";


const router = Router();

router.post("/login", async (req, res, next) => {
    try {
        const credentials = req.body;
        const result = await authService.login(credentials);
        res.send(new ResponseHandler(result));
    } catch(e) {
        next(e);
    }
});

router.patch("/reset-password", (req, res, next) => {
    res.send("password reset");
})

export default router;