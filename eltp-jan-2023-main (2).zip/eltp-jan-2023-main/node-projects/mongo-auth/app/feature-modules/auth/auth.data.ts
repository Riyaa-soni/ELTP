export const ROLES = {
    ADMIN: '123456789'
}