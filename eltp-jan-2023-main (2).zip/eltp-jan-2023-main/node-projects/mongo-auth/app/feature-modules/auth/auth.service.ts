import { sign } from "jsonwebtoken";
import usersService from "../users/users.service";
import { AUTH_RESPONSES } from "./auth.responses";
import { ICredentials } from "./auth.types";


const login = async (credentials: ICredentials) => {
    const user = await usersService.findOne(credentials);
    if(!user) AUTH_RESPONSES.INVALID_CREDENTIALS;

    // extract the id and role, create token send it back
    const { _id } = user;
    const { JWT_SECRET } = process.env;
    // symmetric token
    const token = sign({ id: _id }, JWT_SECRET || '');
    return { token };
}

export default {
    login
}