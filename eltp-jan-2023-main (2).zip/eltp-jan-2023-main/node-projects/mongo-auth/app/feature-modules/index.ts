import UserRouter from './users/users.routes';
import AuthRouter from './auth/auth.routes';

export default {
    UserRouter,
    AuthRouter
}