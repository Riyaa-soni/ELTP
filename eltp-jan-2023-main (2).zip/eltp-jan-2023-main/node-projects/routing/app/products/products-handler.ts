import { Router } from 'express';

const router = Router();

router.get("/", (req, res, next) => {
    res.send("[GET] products")
})

router.post("/", (req, res, next) => {
    res.send("[POST] products")
})

router.put("/", (req, res, next) => {
    res.send("[PUT] products")
})

router.patch("/", (req, res, next) => {
    res.send("[PATCH] products")
})

router.delete("/", (req, res, next) => {
    res.send("[DELETE] products")
})

export default router;