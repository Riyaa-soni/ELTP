import { Router } from 'express';

const router = Router();

router.get("/", (req, res, next) => {
    res.send("[GET] USERS")
})

router.post("/", (req, res, next) => {
    res.send("[POST] USERS")
})

router.put("/", (req, res, next) => {
    res.send("[PUT] USERS")
})

router.patch("/", (req, res, next) => {
    res.send("[PATCH] USERS")
})

router.delete("/", (req, res, next) => {
    res.send("[DELETE] USERS")
})

export default router;