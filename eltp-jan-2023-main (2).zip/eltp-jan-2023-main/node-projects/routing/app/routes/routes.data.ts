import { Route, Routes } from "./routes.types";
import UserRouter from '../users/user-handler';
import ProductRouter from '../products/products-handler';

export const routes: Routes = [
    new Route("/users", UserRouter),
    new Route("/products", ProductRouter),
];
