import { Router } from "express";

// interface IRoutes {
//     path: string;
//     router: Router;
// } 

export type Routes = Route[];

export class Route {
    constructor(
        public path: string,
        public router: Router
    ) {}
}