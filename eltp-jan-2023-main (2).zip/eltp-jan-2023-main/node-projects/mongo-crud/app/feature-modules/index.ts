import UserRouter from './users/users.routes';

export default {
    UserRouter
}