import { Schema, Types } from "mongoose";
import { UserModel } from "./users.schema";
import { IUser } from "./users.types";

const create = (user: IUser) => UserModel.create(user); 

const find = () => UserModel.find({ isDeleted: false });

const findOne = (id: string) => UserModel.findOne({ 
    _id: new Types.ObjectId(id),
    isDeleted: false
});

const update = (user: IUser) => UserModel.updateOne(
    { _id: new Types.ObjectId(user._id) }, 
    user
);

const deleteOne = (id: string) => UserModel.updateOne(
    { _id: new Types.ObjectId(id) }, 
    { isDeleted: true }
);

export default {
    create,
    find, 
    findOne,
    update,
    deleteOne
}