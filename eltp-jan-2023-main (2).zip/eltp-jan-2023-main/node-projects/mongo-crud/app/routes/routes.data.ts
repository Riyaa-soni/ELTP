import { Route, Routes } from "./routes.types";
import Routers from '../feature-modules/index';

export const routes: Routes = [
    new Route("/users", Routers.UserRouter)
];