import { Routes, Route } from "./routes.types";
import AuthRouter from '../auth/auth.routes';

export const routes: Routes = [
    new Route("/auth", AuthRouter)
];