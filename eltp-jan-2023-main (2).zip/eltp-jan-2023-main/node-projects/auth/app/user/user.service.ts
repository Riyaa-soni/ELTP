import userRepo from "./user.repo";
import { IUser, UserPredicate } from "./user.types";

const create = (user: IUser) => userRepo.create(user);

const findOne = (cb: UserPredicate) => userRepo.findOne(cb);

export default {
    create,
    findOne
}