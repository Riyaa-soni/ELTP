// import { body } from "../utility/validate";
import { body } from 'express-validator';
import { validate } from '../utility/validate';

export const LoginValidator = [
    body("email").isEmail().withMessage("email is required"),
    body("password").isString().isLength({ min: 6 }).withMessage("password not correct"),
    validate
]