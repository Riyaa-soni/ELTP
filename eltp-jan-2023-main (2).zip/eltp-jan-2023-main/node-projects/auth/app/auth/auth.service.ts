import userService from "../user/user.service";
import { IUser } from "../user/user.types";
import { AUTH_RESPONSES } from "./auth.responses";
import { ICredentials } from "./auth.types";
import { genSalt, hash, compare } from 'bcryptjs';

const encryptUserPassword = async (user: IUser) => {
    const salt = await genSalt(10);
    const hashedPassword = await hash(user.password, salt);
    user.password = hashedPassword;

    return user;
}

const register = async (user: IUser) => {
    user = await encryptUserPassword(user);
    return userService.create(user);
}

const login = async (
    credential: ICredentials
) => {
    const user = userService.findOne(u => u.email === credential.email);

    if(!user) throw AUTH_RESPONSES.INVALID_CREDENTIALS;

    const isPasswordValid = await compare(credential.password, user.password);
    if(!isPasswordValid) throw AUTH_RESPONSES.INVALID_CREDENTIALS;

    const { password, ...userClone } = user;

    return userClone;
};

export default {
    register,
    login
}