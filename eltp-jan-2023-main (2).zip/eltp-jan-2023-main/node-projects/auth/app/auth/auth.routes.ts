import { Application, NextFunction, Request, RequestHandler, Response, Router } from 'express';
import { validationResult } from 'express-validator';
import { IUser } from '../user/user.types';
import { ResponseHandler } from '../utility/response-handler';
import authService from './auth.service';
import { LoginValidator } from './auth.validations';

const router = Router();

// register a user
router.post("/register", async (req, res, next) => {
    try {
        const user = req.body;
        const result: IUser = await authService.register(user);
        res.send(new ResponseHandler(result));
    } catch (e) {
        next(e);
    }
});


interface A extends RequestHandler {}

router.post("/login", LoginValidator, async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {
        const credentials = req.body;
        const result: Omit<IUser, "password"> = await authService.login(credentials);
        res.send(new ResponseHandler(result));
    } catch (e) {
        next(e);
    }
});

export default router;