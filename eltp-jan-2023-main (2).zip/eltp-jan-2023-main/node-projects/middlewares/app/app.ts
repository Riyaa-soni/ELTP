import express from 'express';

export const createServer = () => {
    const app = express();

    // MIDDLEWARES ARE FUNCTIONS THAT HAVE ACCESS
    // TO REQUEST, RESPONSE AND NEXT
    // REQUEST, RESPONSE AND NEXT ARE PROVIDED
    // BY THE EXPRESS FRAMEWORK.
    // 1 REQUEST CAN HAVE ONLY 1 RESPONSE

    // REGISTER A MIDDLEWARE
    // GLOBAL MIDDLEWARE
    // ANY PATH, ANY METHOD
    app.use((req, res, next) => {
        console.log("[MIDDLEWARE] - 1");
        // res.send("[MIDDLEWARE - 1] response");
        next();
    });

    // GLOBAL MIDDLEWARE
    app.use((req, res, next) => {
        console.log("[MIDDLEWARE] - 2");
        // res.send("response 2"); causes an error
        // res.send("[MIDDLEWARE - 2] response");
        next();
    });

    // ANY METHOD, SPECIFIC PATH
    app.use("/products", (req, res, next) => {
        res.send("[PRODUCTS] response");
    })

    app.use("/products", (req, res, next) => {
        res.send("[M3]");
    })

    // SPECIFIC METHOD, SPECIFIC PATH
    app.get("/product", (req, res, next) => {
        res.send("[PRODUCT] response1");
    })

    app.delete("/product", (req, res, next) => {
        res.send("[PRODUCT] response2");
    })

    const { PORT } = process.env; 
    // STARTS LISTENING TO PORT 3000 OVER HTTP
    // http://localhost:3000/ - BASEURL THAT GETS CREATED
    // ENDPOINT IS THE PATH (URL) THAT IS APPENDED TO THE BASEURL
    app.listen(
        PORT || 3000,
        () => console.log(`SERVER STARTED ON PORT: ${PORT || 3000}`)
    );

    app.get("/", (req, res, next) => {
        res.send("[GET]");
    })

    app.post("/", (req, res, next) => {
        res.send("[POST]");
    })

    app.put("/", (req, res, next) => {
        res.send("[PUT]");
    })

    app.patch("/", (req, res, next) => {
        res.send("[PATCH]");
    })

    app.delete("/", (req, res, next) => {
        res.send("[DELETE]");
    })


}