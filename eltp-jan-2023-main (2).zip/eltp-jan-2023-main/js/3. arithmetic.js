const num1 = 10;
const num2 = 2;

// addition +
num1 + num2; // 12
const addition = num1 + num2;

// subtraction  -
const difference = num1 - num2; // 8

// multiplication *
const product = num1 * num2; // 20

// division /
const division = num1 / num2; // 5
7 / 2; // 3.5

// remainder - mod - %
const remainder = num1 % num2; // 0

// power **
const power = num1 ** num2; // 100

// Not a Number -> NaN
typeof NaN; // number

// Math class and its static methods
Math

// round
Math.round(4.1); // 4
Math.round(4.5); // 5
Math.round(4.6); // 5

// floor
Math.floor(4.1); // 4
Math.floor(4.5); // 4
Math.floor(4.6); // 4

// ceil
Math.ceil(4.1); // 5
Math.ceil(4.5); // 5
Math.ceil(4.6); // 5

// random
Math.random(); // between 0 and 1. excluding 0 and 1

const randomNumber = Math.round(Math.random() * 10);

parseInt('16.7'); // 16
parseFloat('16.7'); // 16.7
parseInt('nine'); // NaN