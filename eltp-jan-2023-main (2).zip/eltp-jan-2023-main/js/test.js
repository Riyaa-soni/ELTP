const three = () => {
    console.log('3');
}

const two = () => {
    console.log('2');
}

const one = () => {
    console.log('1');
}

three();

two();

one();