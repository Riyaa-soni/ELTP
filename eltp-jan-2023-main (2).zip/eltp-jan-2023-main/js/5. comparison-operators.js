// compare two values and evaluate to a boolean

// ==, !=, >, >=, <, <=

5 == 5; // t
5 == 4; // f
4 == 5; // f
'a' == 'a'; // t
4 == 'a'; // f
4 == '4'; // t
true == 'true'; // f

5 != 5; // f
5 != 4; // t
4 != 5; // t
'a' != 'a'; // f
4 != 'a'; // t
4 != '4'; // f
true != 'true'; // t

5 > 5; // f
5 > 4; // t
4 > 5; // f
'a' > 'a'; // f
4 > 'a'; // f
'a' > 4; // f
4 > '4'; // t
true > 'true'; // f

5 >= 5; // t
5 >= 4; // t
4 >= 5; // f
'a' >= 'a'; // t
4 >= 'a'; // f
'a' >= 4; // f
4 >= '4'; // t
true >= 'true'; // f

5 < 5; // f
5 < 4; // f
4 < 5; // t
'a' < 'a'; // f
4 < 'a'; // f
'a' < 4; // f
4 < '4'; // f
true < 'true'; // f

5 <= 5; // t
5 <= 4; // f
4 <= 5; // t
'a' <= 'a'; // t
4 <= 'a'; // f
'a' <= 4; // f
4 <= '4'; // t
true <= 'true'; // f


// ===, !==
// checks the value & the datatype

// ALWAYS USE ===
5 === 5; // true
5 === '5'; // false

// !==
5 !== 6; // true
5 !== '5'; // true



6 == 7; // f
6 === 6; // t
'abcd' === '6174'; // f
6 === true; // false
1 == []; // false
[] === 'abcd'; // false
true == true; // true

// COMMON PITFALL
{} == []; // false
[] == []; // false
{} == {}; // false
[] === []; // false
{} === {}; // false
