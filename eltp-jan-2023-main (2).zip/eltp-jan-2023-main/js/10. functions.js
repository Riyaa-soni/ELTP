// traditional function
function greet() {
    console.log("helloooo");
}

greet; // reference to the function
greet(); // invoking the function
const greetRef = greet;

greetRef(); // invoking the greet function

// anonymous functions
const sayHi = function () {
    console.log("hi");
}

// fat arrow functions
const sayNamaste = () => {
    console.log("Namaste")
}

// paremeterised
function greetPerson(name) {
    console.log(`helooooo, ${name}`);
}

greetPerson(); // undefined is passed
greetPerson("Swarnali");
greetPerson("Swarnali", "ABCD");


function getGreeting() {
    return "HELLOOOOOOOOO";
    // RETURN STOPS THE EXECUTION OF A FUNCTION.

    const num1 = 10;
    const num2 = 5;
    return num1 + num2;
}

const greeting = getGreeting(); // HELLOOOOOOOOO


function createGreeting(name) {
    const greeting = `Helloooooo, ${name}`;
    return greeting;
}

createGreeting();
const fullGreeting = createGreeting("aniruddha");


// 
function addition(n1, n2) {
    return n1 + n2;
}

addition(5, 5); // 10

// omit {} block if function has only 1 statement
const addup = (n1, n2) => n1 + n2;


function addFive(number) {
    return number + 5;
}

// omit () if fn has only 1 parameter
// try using arrow function as much as possible
const add5 = n => n + 5;

