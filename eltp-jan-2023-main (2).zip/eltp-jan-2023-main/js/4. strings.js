const greeting = "hello";
const name = "Vishal"; // assume that this is dynamic

// hello, <name>
// old way 
// +
// concatenates/joins/merges
let fullGreeting = greeting + ", " + name;
// hello, Vishal

// new way ES6+ --> USE THIS
fullGreeting = `${greeting}, ${name}`;
// hello, Vishal

// properties
// length
const word = "chair";
const length = word.length; // 5

// position    1234
const organ = 'nose';
// index       0123

organ[0]; // n
organ[0] = 'p';

// methods
// replace
// creates a new string and replaces the characters
const replacedWord = organ.replace('n', 'p');
// pose

const sentence = "   Hi, welcome to JS   ";
// trim
const sentenceWithoutLTSpaces = sentence.trim();
// "Hi, welcome to JS";

// includes
sentence.includes("hello"); // false
sentence.includes(" ,");// false
sentence.includes("elco");// true

// csv - commas separated values
// , | ~
const csvRow = "bottle, a place to put water|199|grey|10|Riya"; 
// ["bottle", "199", "grey", "10", "Riya"]
// split
csvRow.split("|"); // ["bottle", "199", "grey", "10", "Riya"]

// substring
csvRow.substring(1, 6); // includes the starting index but not ending
// ottle