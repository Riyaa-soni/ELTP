// variable name is x
// = assignment operator
// 5 value/literal 
// puts the value on the RHS of the = in the LHS
x = 5; // NEVER DO THIS.

// var -> AVOID USING THIS.
// declaration
var number; // undefined

// assignment
number = 5;

// re-assignment
number = 10;

// declaration + assignment
var primeNumber = 7;

// let -> prefer let over var.
let negativeNumber = -10;
let age; // undefined

age = 70;

age = 50;

// const -> prefer const over let
const PI = 3.14;

const GRAVITY;
GRAVITY = 9.82; // NOT ALLOWED