const resolvedPromise = new Promise( (resolve,reject) => {
    setTimeout( () => {
        const names = ["gauri", "pratiksha", "rutuja"];
        resolve(names);
    },5000);

});

resolvedPromise.then( (value) => {
    console.log(value[1]);
});
