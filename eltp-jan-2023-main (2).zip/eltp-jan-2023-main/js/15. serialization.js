const serialize = (input) => {
    let stringifiedInput = JSON.stringify(input);
    console.log(stringifiedInput);
    console.log(typeof stringifiedInput);
    let parsedValue = JSON.parse(stringifiedInput);
    console.log(parsedValue);
    console.log(typeof parsedValue);
}

