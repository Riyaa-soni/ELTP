// traditional
// for(initialization; condition; post iteration statement) { 
    // do something while condition is true 
// }

const sentence = "this is a sentence";
const people = ["A", "B", "C"];
const person = { name: "A", age: 10 };


for(let index = 0; index < sentence.length; index++) {
    const char = sentence[index];
    console.log(char);
}

for(let index = 0; index < people.length; index++) {
    const element = people[index];
    console.log(element);
}

const keys = Object.keys(person);
for(let index = 0; index < keys.length; index++) {
    const key = keys[index];
    const value = person[key];
    console.log(value);
}

// for in loop
// for(let index in iterable) {}

for(let index in sentence) {
    const char = sentence[index];
    console.log(char);
}

for(let index in people) {
    const person = people[index];
    console.log(person);
}

for(let key in person) {
    const value = person[key];
    console.log(value);
}

// for of loop
// DOES NOT WORK FOR OBJECTS
for(let char of sentence) {
    console.log(char);
}

for(let element of people) {
    console.log(element);
}


const outerObj = {
    "Rohit": { age: 20 },
    "Aniruddha": { age: 29 }
}

for(let key in outerObj) {
    const innerObj = outerObj[key];
    for(let key in innerObj) {
        const value = innerObj[key];
        console.log(value);
    }
}

// while loop
let index = 0;

while(index < sentence.length) {
    const char = sentence[index];
    console.log(char);

    index++;
}