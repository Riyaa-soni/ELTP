1.
const a = (b = 1) + (2, 3);
console.log(a, b);
why?


2.
let someVar = 10;
function f() {
  console.log(someVar);
  let someVar = 20;
}
f();
and
var someVar = 10;
function f() {
  console.log(someVar);
  var someVar = 20;
}
f();
3.
const output = (function(x){
  delete x;
  return x;
})(0);
console.log(output);
4.
(function(){
  var a = 3;
  b = 3
})();
console.log("a defined? " + (typeof a !== 'undefined'));
console.log("b defined? " + (typeof b !== 'undefined'));
5.
(function f() {
  function f() { return 1; }
  return f();
  function f() { return 2; }
})();