// index         0   1   2   3   4
const numbers = [10, 20, 30, 40, 50];

numbers.length; // 5

// access elements 
numbers[0]; // 10
numbers[100]; // undefined

// numbers[0] = 11; // works, why?

// add elements
// push -> add element the end
// returns the new length of the array
numbers.push(60); // [10, 20, 30, 40, 50, 60];
// -> 6

// unshift -> adds element from the start
// returns the new length of the array
numbers.unshift(0); // [0, 10, 20, 30, 40, 50, 60];
// -> 7


// splice -> adds element in the middle
// returns array of deleted elements
// 1st parameter - index where to start
// 2nd parameter - number of elements to delete
// 3rd parameter onwards all elements you want to add
numbers.splice(3, 0, 25, 26, 27, 28, 29);
// [0, 10, 20, 25, 26, 27, 28, 29, 30, 40, 50, 60];
// -> []

// remove elements
// pop -> deletes element from the end
// -> deleted element
numbers.pop(); // [0, 10, 20, 25, 26, 27, 28, 29, 30, 40, 50];
// -> 60

// shift -> deletes element from start
// -> deleted element
numbers.shift(); // [10, 20, 25, 26, 27, 28, 29, 30, 40, 50];
// -> 0

// splice
// returns array of deleted elements
// 1st parameter - index where to start
// 2nd parameter - number of elements to delete
// 3rd parameter onwards all elements you want to add
numbers.splice(2, 5); // [10, 20, 30, 40, 50];
// [25, 26, 27, 28, 29]

// map, filter, reduce and foreach
// creates a new array of the modified elements
const names = ["Ayondip", "Rohit", "Aarti", "Rohit"];
names.map(str => str.toUpperCase());

names.filter(str => str[0] !== "A");
// ["Rohit", "Rohit"]

const people = [
    { age: 25 },
    { age: 24 },
    { age: 26 },
];

people.filter(person => person.age >= 25);

// reduce
const fibonacci = [1, 1, 2, 3, 5, 8];
const sum = fibonacci.reduce((sum, currentElement) => {
    return sum + currentElement;
}, 0);

sum; // 20

people.forEach(person => {
    person.age = person.age + 5;
});

// come back when we learn about callbacks

// cloning

const puneethFriends = ["Rutuja", "Rohit"];
const joelFriends = puneethFriends;

joelFriends.push("Ganesh");

// slice
const pratikshaFriends = puneethFriends.slice();
pratikshaFriends.push("Gauri");


const riyaFriends = [
    { name: "Vishal", contact: 1004578 },
    { name: "Maitreyi", contact: 1245789 },
    { name: "Swarnali", contact: 0987654321 }
]

// SHALLOW CLONING
const ayondipFriends = riyaFriends.slice();
ayondipFriends.push({ name: "Aniruddha", contact: 9873249324 });

ayondipFriends[0].contact = 987678956;

// assignment => HOW TO DEEP CLONE

// ... spread operator
const rohitFriends = [...ayondipFriends];
// spreads out all elements in the new array

// destructuring

const constants = [3.14, 9.82, 6172];
// const PI = constants[0];
// const g = constants[1];
// const kaprekar = constants[2];

const [PI, g, kaprekar] = constants;
const [, , kap] = constants;

// rest operator ...
const [pi, ...allOthers] = constants;
// pi 3.14
// allOther = [9.82, 6172]