// functions returning from function creates a closure

// const carLoan = (p, n) => p * n * 5 / 100;
// const homeLoan = (p, n) => p * n * 8 / 100;
// const personalLoan = (p, n) => p * n * 10 / 100;

// const loans = () => ({
//     car: (p, n) => p * n * 5 / 100,
//     home: (p, n) => p * n * 5 / 100,
//     personal: (p, n) => p * n * 5 / 100
// })

// factory pattern
const loanFactory = r => (p, n) => p * n * r / 100;

const carLoanCalc = loanFactory(10);
const homeLoanCalc = loanFactory(8);
const personalLoanCalc = loanFactory(5);

carLoanCalc(11000, 6);
homeLoanCalc(50, 10);
