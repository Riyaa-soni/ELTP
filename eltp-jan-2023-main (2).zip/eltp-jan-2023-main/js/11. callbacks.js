// a function reference passed as an argument

const greetAdmin = () => 'Hi, Admin';

const greetEmployee = () => 'Heya, Employee';

const login = (callback) => {
    // callback is reference to a fn
    const message = callback();
    console.log(message);
}

const loggedInUser = 'sdflkj';

if(loggedInUser === 'Admin') {
    login(greetAdmin);
} else {
    login(greetEmployee);
}

Array.prototype.customMap = function(modifierFn) {
    const modifiedArr = [];

    for(let element of this) {
        const modifiedElement = modifierFn(element);
        modifiedArr.push(modifiedElement);
    }

    return modifiedArr;
}

[1, 2, 3, 4, 5].customMap(n => n ** 3);