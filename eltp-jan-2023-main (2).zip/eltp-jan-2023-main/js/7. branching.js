const ageOfPerson = 28;
const thirdFloorAgeThreshold = 25;
const secondFloorAgeThreshold = 18;

if(ageOfPerson >= thirdFloorAgeThreshold) {
    console.log("third floor");
} else if (ageOfPerson >= secondFloorAgeThreshold) {
    console.log("allowed on second floor");
} else {
    console.log("kids, drink water");
}

// else if and else cannot be standalone

// else must always be preceded by if OR else if
// else must aways be preceded by if
// there can be only one if and else but multiple else if are allowed
// if can be standalone -> else if and else are NOT compulsory


const chosenPokemon = 'bulbasaur';

switch(chosenPokemon) {
    case "pikachu":
        console.log("pika pi");
        break;
    case "bulbasaur":
        console.log("bulba");
        break;
    case "squirtle":
        console.log("squuiiiirtle");
        break;
    default:
        console.log("you dont have this pokemon")
}
