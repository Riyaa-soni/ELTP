// js is a loosely typed, dynamic language

// int, float, double, negatives
// number
const integer = 10;
const decimal = 10.5;
const negative = -10;

typeof decimal; // 'number'
console.log(typeof decimal);

// a-z, A-Z, 0-9, ~!@#$%^&*()_+[]{}:;'<>/?|\ 
// it enclosed in '', "" or ``
const singleQuotedString = 'today is Tuesday! the date is 18/01/2023';
const doubleQuotedString = "this is JS!!";
const backeTickedString = `this is a back ticked string`;

typeof backeTickedString; // 'string'

// booleans
// true or false
const hadLunch = false;
const isTall = true;
typeof isTall; // 'boolean'

// undefined
// is a value and a datatype
const dividedByZero = undefined; // NEVER DO THIS.
typeof dividedByZero; // 'undefined'

// null
const zero = null; // NEVER DO THIS.
typeof zero; // 'object'

// arrays
// elements (of any datatype) separated by commas
// enclosed in square brackets []
const integers = [1, 2, 3, 4, 5];

const person = [
    'Aniruddha', 
    29, 
    false, 
    null, 
    undefined, 
    ["Puneeth", "Rohit", "Rohit", "Ayondip", "Swarnali", "Maitreyi", "Ganesh", "Joel", "Rutuja", "Pratiksha", "Gauri", "Vanshika", "Riya", "Vishal"],
    { city: "pune", country: "IN" }
];
typeof person; // object

// object
// key: value pairs, separated by commas
// enclosed in {}

const personObj = {
    name: "Aniruddha",
    age: 29,
    hadLunch: false,
    brain: null,
    pet: undefined,
    friends: ["Puneeth", "Rohit", "Rohit", "Ayondip", "Swarnali", "Maitreyi", "Ganesh", "Joel", "Rutuja", "Pratiksha", "Gauri", "Vanshika", "Riya", "Vishal"],
    address: { city: "pune", country: "IN" }
};

typeof personObj; // object

// function
function hello() {
    console.log('hello');
}

typeof hello; // 'function'