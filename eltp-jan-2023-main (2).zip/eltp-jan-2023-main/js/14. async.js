console.log("line 1");

setTimeout(() => {
    console.log("middle line");
}, 0);

console.log("last line");

const apiWithCallbacks = (successFn, failureFn) => {
    const randomDuration = Math.random() * 5000;
    const db = [{ age: 20 }, { age: 21 }, { age: 22 }];

    setTimeout(() => {
        // the mock data that is return
        const success = Math.random();
        if (success > 0.5) return successFn(db);

        failureFn({ message: 'something went wrong' });
    }, randomDuration);
}

apiWithCallbacks(
    data => apiWithCallbacks(
        d2 => apiWithCallbacks(
            d3 => apiWithCallbacks(
                d4 => { console.log(d4) },
                e4 => { console.log(e4) }),
            e3 => { apiWithCallbacks(d5 => { }, e5 => { }) }),
        e2 => { console.log(e2) }),
    error => console.log(error)
); // undefined


const apiWithPromises = () => {
    const promise = new Promise((resolve, reject) => {
        const randomDuration = Math.random() * 5000;
        const db = [{ age: 20 }, { age: 21 }, { age: 22 }];

        setTimeout(() => {
            // the mock data that is return
            const success = Math.random();
            if (success > 0.5) return resolve(db);

            reject({ message: 'something went wrong' });
        }, randomDuration);
    });

    return promise;
}

apiWithPromises() // promise instance/obj
    .then((data) => {
        // go to the next then block
        return apiWithPromises();
    })
    .then(data2 => {
        console.log(data2);
    })
    .catch((error) => { console.log(error) })
    .finally(() => { console.log("done") })


class Person {
    constructor(name) {
        this.name = name;
    }

    capitalize() {
        this.name = this.name.toUpperCase();
        return this;
    }

    lower() {
        this.name = this.name.toLowerCase();
        return this;
    }
}

const person = new Person("aniruddha"); // this -> { name: "aniruddha" }
// const p = new Person("abcd")
person.capitalize()
    .lower().capitalize().lower().lower().capitalize(); // reference to person



const apiWithAsyncAwait = async () => {
    try{
        const data = await apiWithPromises();
        console.log(data);
    } catch(e) {
        console.log(e);
    }
}

apiWithAsyncAwait();

const getUsers = async () => {
    const response = await fetch("https://jsonplaceholder.typicode.com/users");
    const data = await response.json();

    console.log(data);
}

getUsers();