// AND, OR and NOT

// AND &&
true && true; // true
true && false; // false
false && true; // false
false && false; // false

// OR ||
true || true; // true
true || false; // true
false || true; // true
false || false; // false

// NOT !
!true // false
!false // true

// TRUTHY & FALSY
// 0, "", null, undefined, NaN, false ---> FALSY
0 || false; // false
1 && false; // false
1 || true; // true


const name = "" || "abcd";
// "abcd"