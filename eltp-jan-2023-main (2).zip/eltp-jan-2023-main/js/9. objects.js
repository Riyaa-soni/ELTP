const dynamicKey = "sponsor";

const cricketPlayer = {
    name: "Mahendra",
    lastname: "Dhoni",
    age: 42,
    canBat: false,
    canBowl: false,
    lastFiveScores: [13, 15, 0, 0, 5],
    family: {
        sakshi: {
            relation: "wife",
            age: 37
        },
        ziva: {
            relation: "daughter",
            age: 5
        }
    },
    captaincy: null,
    talent: undefined,
    bat: function() {
        console.log(`${this.name} cannot bat`)
    },
    keep: () => {
        console.log(`${this.lastname} cannot keep`)
    },
    // put a key called "sponsor"
    // with value "Nike"
    [dynamicKey]: "Nike"
}

// access a value
// . operator
cricketPlayer.age; // 42
cricketPlayer.family.ziva.age; // 5
cricketPlayer.lastFiveScores[4]; // 5

// ["key name"]
cricketPlayer["canBowl"]; // false

const key = "lastname";
cricketPlayer[key]; // "Dhoni"

cricketPlayer.key; // undefined

// change the property value
cricketPlayer.talent = true;

// add a property
cricketPlayer.fifties = 30;
cricketPlayer["hundreds"] = 20;

const referenceToBat = cricketPlayer.bat; // invokes the bat method
referenceToBat();
cricketPlayer.keep(); // invokes the keep method

// Object classes static methods
// hasOwnproperty
cricketPlayer.hasOwnProperty("fifties"); // true

// Object.keys
const person = { name: "abcd", age: 25 };
Object.keys(person);
// ["name", "age"]

// Object.values
Object.values(person);
// ["abcd", 25]

const constants = {
    PI: 3.14,
    G: 9.82,
    KAPREKAR: 6172
}

// const PI = constants.PI;
// const G = constants.G;
// const kaprekar = constants.KAPREKAR;

const G = 100;
const { G: GRAVITY, PI } = constants;
const { PI: p, ...others } = constants;
const constantClone = { ...constants };


