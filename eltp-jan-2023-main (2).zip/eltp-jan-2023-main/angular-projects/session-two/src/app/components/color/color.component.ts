import {Component, Input} from '@angular/core';

@Component({
    selector: 'app-color',
    templateUrl: './color.component.html'
})
export class ColorComponent {
    @Input() color = '';
}