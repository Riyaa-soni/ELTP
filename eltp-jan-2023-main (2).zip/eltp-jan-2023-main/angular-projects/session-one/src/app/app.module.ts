import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { NameComponent } from './components/name/name.component';

@NgModule({
  // components, pipes, directives are part of the module
  declarations: [
    AppComponent,
    NameComponent
  ],
  imports: [
    BrowserModule
  ],
  // services
  providers: [],
  // starting point of the module
  bootstrap: [AppComponent]
})
export class AppModule { }
