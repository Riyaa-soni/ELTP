import { Component } from '@angular/core';

@Component({
  // what tag to use for this component
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'session-one';
}
