import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  addClassToDiv1 = true;
  addClassToDiv2 = true;

  width100 = false;
  width50 = false;
  round = false;
  pad50 = false;
  pad0 = false;
  red = false;

  setWidth100() {
    this.width100 = !this.width100;
  }
  setWidth50() {
    this.width50 = !this.width50;
  }
  setRound() {
    this.round = !this.round;
  }
  setPad50() {
    this.pad50 = !this.pad50;
  }
  setPad0() {
    this.pad0 = !this.pad0;
  }
  setRed() {
    this.red = !this.red;
  }
}
