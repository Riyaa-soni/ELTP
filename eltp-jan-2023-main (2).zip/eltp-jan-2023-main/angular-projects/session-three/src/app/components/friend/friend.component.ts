import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-friend',
  templateUrl: './friend.component.html',
  styleUrls: ['./friend.component.scss']
})
export class FriendComponent {
  @Input() name = '';
  @Input() email = '';
  @Input() address = '';
  @Input() status = '';
  @Output() togglePayment = new EventEmitter();
  @Output() toggleFriendShip = new EventEmitter();

  getStatusText() {
    return this.status.toLowerCase().split("_").join(" ");
  } 

  handlePaymentClick() {
    this.togglePayment.emit();
  }

  handleFriendshipClick() {
    this.toggleFriendShip.emit();
  }
}
