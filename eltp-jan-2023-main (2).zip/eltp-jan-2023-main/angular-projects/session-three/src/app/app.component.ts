import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  friends = [
    { 
      name: 'Vishal', 
      email: 'vishal@coditas.com', 
      address: '123 abc apts', 
      status: "PAYMENT_PENDING",
      isClose: false 
    },
    { 
      name: 'Ayondip', 
      email: 'ayondip@coditas.com', 
      address: '456 pqrs apts', 
      status: "PAYMENT_DONE",
      isClose: false 
    },
  ]

  getClass(isClose: boolean) {
    return `friend ${isClose ? 'friend__close': ''}`
  }

  changePaymentStatus(index: number) {
    if(this.friends[index].status === "PAYMENT_PENDING") {
      return this.friends[index].status = "PAYMENT_DONE"
    }

    return this.friends[index].status = "PAYMENT_PENDING"
  }

  changeFriendshipCloseness(index: number) {
    this.friends[index].isClose = !this.friends[index].isClose
  } 
}
