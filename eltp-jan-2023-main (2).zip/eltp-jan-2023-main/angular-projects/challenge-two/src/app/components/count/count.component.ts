import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-count',
  templateUrl: './count.component.html',
  styleUrls: ['./count.component.scss']
})
export class CountComponent {
  @Input() count = 0;
  @Output() onIncrement = new EventEmitter();

  incrementCount() {
    this.onIncrement.emit();
  }

}
