import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  count1 = 0;
  count2 = 0;

  incrementCount(countStr: "count1" | "count2") {
    this[countStr]++;
  }
}
