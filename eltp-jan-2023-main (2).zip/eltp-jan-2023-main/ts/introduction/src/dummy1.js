"use strict";
console.log("dummy1");
