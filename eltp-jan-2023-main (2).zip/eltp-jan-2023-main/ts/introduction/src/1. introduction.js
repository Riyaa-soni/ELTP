"use strict";
console.log("this is typescript");
// literal type
var number = 5;
// infer the type from the values
var num = 5;
num = 6; // allowed
num = "abcd"; // not allowed
