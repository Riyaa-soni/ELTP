console.log("this is typescript");

// literal type
const number = 5;

// infer the type from the values
let num = 5;
num = 6; // allowed
num = "abcd"; // not allowed