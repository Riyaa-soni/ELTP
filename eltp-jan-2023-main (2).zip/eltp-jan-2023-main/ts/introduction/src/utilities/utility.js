"use strict";
console.log("utility");
