// let name = "aniruddha";
// declaration = type = any
// DO NOT DO THIS (no variables with type ANY)
let futureName: string;

futureName = "abcd";
// futureName = 5; not allowed
let number: number;
number = 5;

let isTypeScriptAwesome:  boolean;
isTypeScriptAwesome = true;

let something: undefined;
something = undefined;

type nullType = null;
let nullVar: nullType;
nullVar = null;

// 
const integers = [1, 2, 3, 4];
// integers.push({});
const strings: string[] = ['abcd', 'pqrs'];

type AlphaNum = string | number;
type AlphaNums = AlphaNum[];
                // (string | number)[]
                // AlphaNum[]
const alphaNumeric: AlphaNums = [];

// 
const person = {
    name: 'abcd',
    age: 10
}

const p1: { name: string, age: number } = {
    name: 'abcd',
    age: 10
}

const p2: Person = {
    name: 'pqrs',
    age: 20
}

// type
type TypePerson = { name: string, age: number };
interface IPerson { name: string, age: number };
class Person { name: string; age: number };

//
const greet: Function = () => {

} 
const greet1: () => void = () => {

}

const greet2: (n: string, p: number) => string = (n: string) => {
    return '';
}  
